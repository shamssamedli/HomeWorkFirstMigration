﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HomeWorkDbConnect.DAL;
using HomeWorkDbConnect.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace HomeWorkDbConnect.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _db;
        public HomeController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            TeacherDrugVM vm = new TeacherDrugVM
            {
                Teachers=_db.Teachers,
                Drugs=_db.Drugs
            };
            return View(vm);
        }
    }
}