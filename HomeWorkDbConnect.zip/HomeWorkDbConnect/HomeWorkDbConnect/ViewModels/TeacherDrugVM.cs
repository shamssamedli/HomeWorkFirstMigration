﻿using HomeWorkDbConnect.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HomeWorkDbConnect.ViewModels
{
    public class TeacherDrugVM
    {
        public IEnumerable<Teacher> Teachers { get; set; }
        public IEnumerable<Drug> Drugs{ get; set; }
    }
}
